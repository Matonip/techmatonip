export const rewardsValues = {
  all: '100',
  half: '50',
  none: '0',
};

export default null;
