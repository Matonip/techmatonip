module.exports = require('./makeConfig')({
  isDevelopment: true,
});
