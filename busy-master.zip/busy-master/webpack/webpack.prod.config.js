module.exports = require('./makeConfig')({
  isDevelopment: false,
});
